#pragma once
class AiStrategy
{
public:
	int GetPoints();
};