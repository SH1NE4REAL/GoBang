#pragma once
class coordinate
{
public:
	int x;
	int y;
};